using System.Diagnostics;
using IdentityDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace IdentityDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            string user = "Saklen";

            ViewData["msg"] = "Hello " + user;
            ViewData["count"] = 10;
            TempData["TempMsg"] = "hi i am from temp";
            ViewBag.count = 20;
            return View(nameof(Print));
        }

        public IActionResult Print()
        {
            return View();
        }
       
       
    }
}
