﻿using Microsoft.AspNetCore.Mvc;

namespace IdentityDemo.Controllers
{
    public class SecretController : Controller
    {
        public IActionResult Index()
        {
            return Content("This is a secret page. You are logged in!");
        }
    }
}
