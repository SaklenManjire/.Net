﻿using System.ComponentModel.DataAnnotations;

namespace studdb
{
    class Courses
    {
        [Key]
        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public int StudentId { get; set; }

        public Student student { get; set; }


    }
}
