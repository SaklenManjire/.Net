﻿using Microsoft.EntityFrameworkCore;

namespace studdb
{
    class SbContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(LocalDB)\\MSSQLLocalDB;Database=newmydb;Trusted_Connection=True");
        }
    }
}
