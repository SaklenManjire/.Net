﻿using System.ComponentModel.DataAnnotations;

namespace studdb
{
    class Student
    {
        [Key]
        public int StudId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public List<Courses> CourseId { get; set; }
    }
}
