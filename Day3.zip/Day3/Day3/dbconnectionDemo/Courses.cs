﻿using System.ComponentModel.DataAnnotations;

namespace dbconnectionDemo
{
    class Courses
    {
        [Key]
        public int Course_id { get; set; }
        public string Coursename { get; set; }
    }

}
