﻿using System.ComponentModel.DataAnnotations;

namespace dbconnectionDemo
{
    class Student
    {
        [Key]
        public int RollNo { get; set; }

        public string Name { get; set; }
    }

}
