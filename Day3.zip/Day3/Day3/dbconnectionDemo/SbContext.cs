﻿using Microsoft.EntityFrameworkCore;

namespace dbconnectionDemo
{
    class SbContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Courses> Courses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(LocalDB)\\MSSQLLocalDB;Database=mydb;Trusted_Connection=True");
        }

    }

}
