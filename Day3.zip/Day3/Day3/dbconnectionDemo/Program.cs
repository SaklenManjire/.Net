﻿using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System.Xml.Serialization;

namespace dbconnectionDemo
{

    class Program
    {
        static SbContext sb = new SbContext();


        //select data
        public static List<Student> GetAllStudent()
        {
            return sb.Students.ToList();
        }


        //insert data
        public static int Add(string name)
        {
            Student s = new Student()
            {
                Name = name
            };
            sb.Students.Add(s);
            return sb.SaveChanges();
            
        }

        //find
        public static Student FindStud(int id)
        {
            Student s=sb.Students.Find(id);
            return s;
        }


        //update
        public static int Update(int id1,string name1)
        {
            Student s = sb.Students.Find(id1);
            if (s == null)
            {
                Console.WriteLine("Student Not Found");
                return 0;
            }     
            else
                s.Name = name1;
            return sb.SaveChanges();

        }

        public static int Delete(int id2)
        {
            Student s = sb.Students.Find(id2);
            if (s == null)
            {
                Console.WriteLine("Student Not Found");
                return 0;
            }
            else
            {
                sb.Remove(s);
                return sb.SaveChanges();
            }
               

        }



        static void Main(string[] args)
        {

            int choice;


            do
            {
                Console.WriteLine("\n**** Student Menu Driven Program ****");
                Console.WriteLine("0.Exit\n1.Show\n2.Add\n3.find\n4.Update\n5.Delete\n");
                Console.WriteLine("Enter Your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 0:
                        break;
                    case 1:
                        Console.WriteLine("***** Student Details *****");
                        //select
                        List<Student> stud = GetAllStudent();
                        foreach (var item in stud)
                        {
                            Console.WriteLine(item.RollNo + ":" + item.Name);

                        }
                        break;
                    case 2:
                        string name;
                        Console.WriteLine("Enter Name:");
                        name = Console.ReadLine();
                        int a = Add(name);
                        if (a != 1)
                        {
                            Console.WriteLine("Data Not Added successfully");
                        }
                        else
                        {
                            Console.WriteLine("Data  Added successfully");
                        }
                        break;
                    case 3:
                        int id;
                        Console.WriteLine("Enter Student Id:");
                        id = Convert.ToInt32(Console.ReadLine());
                        Student s = FindStud(id);
                        if(s==null)
                            Console.WriteLine("Student Not Found");
                        else
                            Console.WriteLine($"\nStudent is finded:\nName:{s.Name}\nRoll No:{s.RollNo}");
                        break;
                    case 4:
                        int id1;
                        Console.WriteLine("Enter Student Id To Update:");
                        id1 = Convert.ToInt32(Console.ReadLine());
                        string name1;
                        Console.WriteLine("Enter Name To Update:");
                        name1 = Console.ReadLine();
                        int affect = Update(id1, name1);
                        if (affect != 1)
                            Console.WriteLine("Data Not Updated successfully");
                        else
                            Console.WriteLine("Data Updated successfully ");
                            break;
                    case 5:
                        int id2;
                        Console.WriteLine("Enter Student Id To Delete:");
                        id2 = Convert.ToInt32(Console.ReadLine());
                        int a2 = Delete(id2);
                        if (a2 != 1)
                        {
                            Console.WriteLine("Data Not Deleted successfully");
                        }
                        break;

                    default:
                        Console.WriteLine("Incorrect choice");
                        break;


                }
            } while (choice != 0);
            

            //insert
            //int a = Add();
            //Console.WriteLine("Row Affected:"+a);

            //find
            //Student s=FindStud();
            //Console.WriteLine($"\nStudent Name is finded:\nName:{s.Name}\nRoll No:{s.RollNo}");

            //update
            //Console.WriteLine(Update());
            
            //Console.WriteLine(Delete());

        }
      

    }

}
