﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCourseManagement.Models;
using StudentCourseManagement.Models.StudentCourseManagement.Data;

namespace StudentCourseManagement.Controllers
{
    public class StudentController : Controller
    {

        ApplicationDbContext _context=new ApplicationDbContext();
        public IActionResult Index()
        {
            List<Student> s=_context.Students.Include(s => s.Courses).ToList();
            return View(s);
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult AfterCreate(Student s)
        {
            _context.Add(s);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            return View(_context.Students.Find(id));
        }

        public IActionResult AfterEdit(Student s)
        {
            Student s1 = _context.Students.Find(s.StudentId);
            s1.FirstName = s.FirstName;
            s1.LastName = s.LastName;
            _context.SaveChanges();
            return RedirectToAction("Index");  
        }

        public IActionResult Delete(int id)
        {
            Student s1 = _context.Students.Find(id);
            _context.Students.Remove(s1);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }



    }
}
