using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCourseManagement.Models;
using StudentCourseManagement.Models.StudentCourseManagement.Data;
using System.Diagnostics;

namespace StudentCourseManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        ApplicationDbContext _context = new ApplicationDbContext();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {

            return View();
        }

        //public IActionResult Create()
        //{
        //    return View("StudeView/Create");
        //}

        //[HttpPost]
        //public IActionResult AfterCreate(Student student)
        //{
        //    _context.Students.Add(student);
        //    _context.SaveChanges();
        //    return Redirect("StudeView/Index");
        //}

        //public IActionResult Edit(int id)
        //{
        //    return View(_context.Students.Find(id));
        //}

        //[HttpPost]
        //public IActionResult Edit(Student student)
        //{
        //    _context.Students.Update(student);
        //    _context.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //public IActionResult Delete(int id)
        //{
        //    var student = _context.Students.Find(id);
        //    _context.Students.Remove(student);
        //    _context.SaveChanges();
        //    return RedirectToAction("Index");
        //}
    }
}
