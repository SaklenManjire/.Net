﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentCourseManagement.Models;
using StudentCourseManagement.Models.StudentCourseManagement.Data;

namespace StudentCourseManagement.Controllers
{
    public class CourseController : Controller
    {
        ApplicationDbContext _context=new ApplicationDbContext();
        public IActionResult Index()
        {   
            return View(_context.Courses.ToList());
        }

        private void PopulateStudent(Object selectedStudent =null)
        {
            var students = _context.Students.OrderBy(s => s.FirstName).ToList();
            ViewBag.StudentList = new SelectList(students, "StudentId", "FirstName", selectedStudent);
        }

        public IActionResult Create()
        {
            PopulateStudent();
            return View();
        }

        public IActionResult AfterCreate(Course c)
        {
            _context.Courses.Add(c);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            Course course = _context.Courses.Include(course => course.Student).FirstOrDefault(course => course.CourseId == id);
            _context.Courses.Remove(course);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            
            Course c = _context.Courses.Find(id);
            PopulateStudent(c.StudentId);
            return View(c);
        }

        public IActionResult AfterEdit(Course c)
        {
            _context.Courses.Update(c);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }



    }
}
