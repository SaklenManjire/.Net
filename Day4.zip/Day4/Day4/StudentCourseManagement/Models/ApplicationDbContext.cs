﻿using Microsoft.EntityFrameworkCore;

namespace StudentCourseManagement.Models
{
    namespace StudentCourseManagement.Data
    {
        public class ApplicationDbContext : DbContext
        {
          
            public DbSet<Student> Students { get; set; }
            public DbSet<Course> Courses { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                optionsBuilder.UseSqlServer("Server=(LocalDB)\\MSSQLLocalDB;Database=StudentDb;Trusted_Connection=True");
            }
        }
    }
}
