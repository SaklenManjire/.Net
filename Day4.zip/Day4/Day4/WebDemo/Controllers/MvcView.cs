﻿namespace WebDemo.Controllers
{
    public class MvcView
    {
    }
}
