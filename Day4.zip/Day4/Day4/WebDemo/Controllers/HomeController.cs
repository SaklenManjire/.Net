using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebDemo.Models;

namespace WebDemo.Controllers
{
   
    public class HomeController : Controller
    {
        SbContext sb = new SbContext();
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
           
        }

        public IActionResult Index()
        {
            List<Student> slist= sb.Students.ToList();
            return View(slist);
        }

        public IActionResult Create(Student student)
        {
            sb.Add(student);
            sb.SaveChanges();
            return View(student);
        }
       


    }
}
