ing Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebDemo.Views.Home
{
    public class AddStudentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
