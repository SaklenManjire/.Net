using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebDemo.Views.Home
{
    public class ShowStudModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
