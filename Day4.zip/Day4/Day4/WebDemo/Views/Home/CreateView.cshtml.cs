using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebDemo.Views.Home
{
    public class CreateViewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
