﻿using Microsoft.EntityFrameworkCore;

namespace WebDemo.Models
{
    public class SbContext:DbContext
    {
        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(LocalDB)\\MSSQLLocalDB;Database=StudDatabase;Trusted_Connection=True");
        }
    }
}
