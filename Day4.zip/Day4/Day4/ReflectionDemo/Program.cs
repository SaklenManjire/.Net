﻿using System;
using System.IO;
using System.Reflection;

namespace ReflectionDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("**** Reflection Demo ****\n");

            Reflection r = new Reflection()
            {
                path = "D:\\Sunbeam(Training Program)\\Day4\\Day4\\MathsLibrary\\bin\\Debug\\net8.0\\MathsLibrary.dll"
            };

            r.ReflectAndInvoke();
        }
    }

    public class Reflection
    {
        public String path;

        public void ReflectAndInvoke()
        {
            Assembly assembly = Assembly.LoadFrom(path);
            Console.WriteLine($"\n--- Reflecting Assembly: {assembly.FullName} ---\n");

            Type[] allTypesInAssembly = assembly.GetTypes();
            foreach (var type in allTypesInAssembly)
            {
                Console.WriteLine("Full Name: " + type.FullName);

                object instance = assembly.CreateInstance(type.FullName);

                MethodInfo[] allMethods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);

                Console.WriteLine($"  Methods found: {allMethods.Length}");

                foreach (var method in allMethods)
                {
                    Console.WriteLine($"\n  --- Processing Method: {method.Name} ---");
                    ParameterInfo[] parms = method.GetParameters();
                    object[] arguments = new object[parms.Length];

                    Console.WriteLine($"    Parameters needed: {parms.Length}");

                    for (int i = 0; i < parms.Length; i++)
                    {
                        ParameterInfo parm = parms[i];
                        Console.Write($"    Enter value for [{parm.ParameterType.Name}] {parm.Name}: ");
                        string userInput = Console.ReadLine();
                        arguments[i] = Convert.ChangeType(userInput, parm.ParameterType);
                    }

                    if (instance != null)
                    {
                        object result = method.Invoke(instance, arguments);
                        Console.WriteLine($"\n    Method invoked successfully. Result: {result}");
                    }
                    else
                    {
                        Console.WriteLine("    Could not create instance of the class to invoke method.");
                    }
                }
            }
        }
    }
}
