﻿using MathsLibrary;

namespace LibraryDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Maths m=new Maths();
            Console.WriteLine(m.Add(2, 3));
        }

        


    }
}
