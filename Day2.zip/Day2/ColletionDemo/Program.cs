﻿using System.Collections;

namespace ColletionDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //#region non-generic legacy
            //ArrayList names = new ArrayList();
            //names.Add("Saklen");
            //names.Add(12);
            //names.Add(12.12);
            //names.Add(false);
            //foreach (var item in names)
            //{
            //    Console.WriteLine(item);
            //    if (item == "Saklen")
            //    {
            //        Console.WriteLine("Matched");
            //    }
            //}


            //#endregion


            //#region generic
            //List<string> list= new List<string>();
            //list.Add("Hello");
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}

            //Dictionary<int, string> d = new Dictionary<int, string>();
            //d.Add(1, "new");
            //d.Add(2, "");
            //d.Add(3, "new");
            //foreach (var item in d)
            //{
            //    Console.WriteLine(item);
            //}
            //#endregion
       

            //Employee employee = new Employee();
         

            List<Employee> e = new List<Employee>();
            e.Add(new Employee() { Id=1,Name="saklen",Salary=13400 ,Address="Sangli"});
            e.Add(new Employee() { Id = 2, Name = "swapnil", Salary = 11200, Address = "Pune" });
            e.Add(new Employee() { Id = 3, Name = "Om", Salary = 123200,Address = "Karad" });
            e.Add(new Employee() { Id = 4, Name = "Anurag", Salary = 123400, Address = "Pune" });
            e.Add(new Employee() { Id = 5, Name = "Kaushal", Salary = 123400, Address = "Mumbai" });
            //foreach (var item in e)
            //{
            //    item.Display();
            //}

            foreach (var item in e)
            {
                //if (item.Address == "Pune")
                //{
                //    item.Display();
                //}

                if (item.Address.Contains("P"))
                {
                    item.Display();
                }
            }

            

        }
    }

     class Employee
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name { get; set; }

        public string Address { get; set; }

        private double _salary;

        public double Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }

        //public  void Accept()
        //{
        //    Console.WriteLine("Enter Id:");
        //    Id = Convert.ToInt32(Console.ReadLine());
        //    Console.WriteLine("Enter Name:");
        //    Name = Console.ReadLine();
        //    Console.WriteLine("Enter Salary:");
        //    Salary = Convert.ToDouble(Console.ReadLine());

        //}

        public  void Display()
        {
            Console.WriteLine("\nId:" + Id);
            Console.WriteLine("Name:" + Name);
            Console.WriteLine("Basic Salary:" + Salary);
            Console.WriteLine("Address:" + Address + "\n");
        }

    }
}


