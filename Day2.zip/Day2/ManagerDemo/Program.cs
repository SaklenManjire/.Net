﻿using System.ComponentModel;

namespace ManagerDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Employee employee = new Manager();
            //employee.Accept();
            //employee.DoWork();
            //Console.WriteLine("Manager Salary:"+employee.Calsal());

            Console.WriteLine("0.Manager\n1.Sales Manager\n2.Exit");
            Console.WriteLine("Enter your choice:");
            int choice;
            choice=Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 0:
                    Employee e1 = new Manager();
                    if (e1 != null)
                    {
                        Console.WriteLine("Designation:Manager");
                        e1.Accept();
                        e1.Display();
                        e1.DoWork();
                        Console.WriteLine("Manager Salary:" + e1.Calsal());
                    }
                    break;
                case 1:
                    Employee e2 = new SalesManager();
                    if (e2 != null)
                    {
                        Console.WriteLine("Designation:Sales Manager");
                        e2.Accept();
                        e2.Display();
                        e2.DoWork();
                        Console.WriteLine("Sales Manager Salary:" + e2.Calsal());
                    }
                    break;
                case 2:
                    break;
                default:
                    Console.WriteLine("No Match");
                    break;
            }
            

        }
    }

    abstract class Employee
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        private double _salary;

        public double Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }

        public virtual void Accept()
        {
            Console.WriteLine("Enter Id:");
            Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Salary:");
            Salary = Convert.ToDouble(Console.ReadLine());

        }

        public abstract void DoWork();

        public virtual double Calsal()
        {
            return Salary;
        }

        public virtual void Display()
        {
            Console.WriteLine("\nId:"+Id);
            Console.WriteLine("Basic Salary:"+Salary);
        }

    }

    class Manager : Employee
    {

        private double _bonus;

        public double Bonus
        {
            get { return _bonus; }
            set { _bonus = value; }
        }


        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter Manager Bonus:");
            Bonus= Convert.ToDouble(Console.ReadLine());

        }

        public override void DoWork()
        {
            Console.WriteLine("Manages Employees");
        }

        public override double Calsal()
        {
            return Salary + Bonus;
        }

        public virtual void Display()
        {
            base.Display();
        }

    }

    class SalesManager : Employee
    {
        private double _commision;

        public double Commision
        {
            get { return _commision; }
            set { _commision = value; }
        }


    public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter SalesManager Commsion:");
            Commision = Convert.ToDouble(Console.ReadLine());

        }

        public override void DoWork()
        {
            Console.WriteLine("Manages Marketing");
        }

        public override double Calsal()
        {
            return Salary + Commision;
        }
    }


    //abecause of absract class
    //class Labour:Employee
    //{
       
    //}

    
}
