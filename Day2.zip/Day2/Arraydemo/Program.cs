﻿namespace Arraydemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 12, 23, 45 };
            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
            }
            int[] b=new int[3];
            for (int i = 0; i < b.Length; i++)
            {
                Console.WriteLine("Enter Value:" + i);
                b[i] =Convert.ToInt32(Console.ReadLine());
            }

            foreach (var item in b)
            {
                Console.WriteLine(item);
            }

            string [] c=new string[3];
            for (int i = 0; i < c.Length; i++)
            {
                Console.WriteLine("Enter value:"+i);
                c[i] = Console.ReadLine();
            }

            foreach (var item in c)
            {
                Console.WriteLine(item);
            }


        }
    }
}
