﻿namespace DatatypeDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Father Name :");
            string f_name=Console.ReadLine();
            Console.WriteLine("Enter Any Number:");
            int num=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Any Boolean Value:");
            bool b=Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine($"Father Name:{f_name} Number:{num} Boolean value:{b}");
            

    }
    }
}
