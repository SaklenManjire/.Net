﻿namespace LinqDemo
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int CourseId { get; set; }
    }

    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }

     class Program
    {
        static void Main(string[] args)
        {
            var student = new List<Student>
            {
                 new Student { Id = 1, Name = "Alice", Address = "Mumbai", CourseId = 101 },
                 new Student { Id = 2, Name = "Bob", Address = "Pune", CourseId = 102 },
                 new Student { Id = 3, Name = "Charlie", Address = "Delhi", CourseId = 101 },
                 new Student { Id = 4, Name = "Anita", Address = "Mumbai", CourseId = 103 }
            };

            var course = new List<Course>
            {
                new Course { CourseId = 101, CourseName = "Math" },
                new Course { CourseId = 102, CourseName = "Science" },
                new Course { CourseId = 103, CourseName = "English" }

            };

            Console.WriteLine("Enter Character seacrh in Address");
            string filter = Console.ReadLine();
            var result =(from s in student
                         where s.Address.Contains(filter)
                         select s).ToList(); ;
            Console.WriteLine(result);
            foreach (var item in result)
            {
                Console.WriteLine(item.Name);
            }
        }
    }
}
