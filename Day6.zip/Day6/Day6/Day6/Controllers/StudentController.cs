﻿using Day6.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Day6.Controllers
{
    public class StudentController : Controller
    {
         SbContext db=new SbContext();
        public IActionResult Index()
        {
            List<Student> s = db.Students.Include(s => s.courses).ToList();
            return View(s);
        }

        private void PopulateStudent(Object selectedCourse = null)
        {
            var courses = db.Courses.OrderBy(s => s.CourseName).ToList();
            ViewBag.CourseList = new SelectList(courses, "CourseId", "CourseName", selectedCourse);
        }

        public IActionResult Create()
        {
            PopulateStudent();
            return View();
        }

        public IActionResult AfterCreate(Student s)
        {
            db.Students.Add(s);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            Student s = db.Students.Find(id);
            db.Students.Remove(s);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
