﻿using Microsoft.AspNetCore.Mvc;

namespace Day6.Controllers
{
    public class CourseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
