﻿namespace Day6.Models
{
    public class Course
    {
        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public List<Student> students { get; set; }
    }
}
