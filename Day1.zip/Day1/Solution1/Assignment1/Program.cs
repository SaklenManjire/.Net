﻿namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>()
           {
               new Student(),
               new Student(),
               new Student()
           };

            foreach (var item in students)
            {
                Console.WriteLine("***** Enter Student details *****");
                item.Accept();
                item.Display();
            }

        }
    }

    class Student
    {
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private int _rollNo;

        public int RollNo
        {
            get { return _rollNo; }
            set { _rollNo = value; }
        }

        private int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }


        private string _course;

        public string Course
        {
            get { return _course; }
            set { _course = value; }
        }

        public void Accept()
        {
            string num;
            Console.WriteLine("Enter Student Name:");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Student Roll No:");
            RollNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student Age:");
            while (true)
            {
                num = Console.ReadLine();
                try
                {
                    Age = Convert.ToInt32(num);
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Age must be number.");
                }
            }
            Console.WriteLine("Enter Student Course:");
            Course = Console.ReadLine();
        }
        public void Display()
        {
            Console.WriteLine("***** Student Details *****");
            Console.WriteLine($"Name:{Name}\nAge:{Age}\nRoll No:{RollNo}\nCourse:{Course}\n");

        }
    }
}
