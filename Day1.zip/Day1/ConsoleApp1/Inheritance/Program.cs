﻿namespace Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p=new Employee(1,20000);
            p.Name = "Saklen";
            p.Age= 30;
            //calling the employee display
            p.display();
        }
    }

    class Person
    {

        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        //virtual method 
        public virtual void display()
        {
            Console.WriteLine($"{Name} {Age}");
        }
    }

    class Employee : Person
    {

        public Employee(int id,int salary)
        {
            this.Id = id;
            this.Salary = salary;
        }
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        private int _salary;

        public int Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }
        
        public  override void display()
        {
            Console.WriteLine("Calling Employee display method.");
            Console.WriteLine($"Name:{Name} Age:{Age} Id:{Id} Salary:{Salary}");
        }

    }

}
