﻿namespace ClassDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

           Student student = new Student();
           //Access Property
           student.Name = "Kaushal";
           Console.WriteLine("Student Name:"+student.Name);
           Student student1 = new Student(21,"Saklen","CSE");
           Console.WriteLine($"Name:{student1.Name}");
        }
    }

    class Student
    {
        int roll_no;
        string name;
        string course;


        //Default Constructor
        public Student()
        {
            Console.WriteLine("Default Constructor");
        }


        //Parameterized Constructor
        public Student(int roll_no, string name, string course)
        {
            this.roll_no = roll_no;
            this.name = name;
            this.course = course;
        }


        //Property
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int _clg_name;

        public int ClgName
        {
            get { return _clg_name; }
            set { _clg_name = value; }
        }

    }
}
