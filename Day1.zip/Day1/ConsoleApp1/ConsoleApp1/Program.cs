﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Writeline
            Console.WriteLine("Hello, World!");

            //using + 
            Console.WriteLine("Hello:" + "Saklen");

            //placeholder
            string name = "Saklen";
            Console.WriteLine("name :{0}", name);

            //string interpolation
            Console.WriteLine($"name:{name}");
            #endregion

            #region readline
            Console.WriteLine("Enter Name:");
            string name1;
            name1=Console.ReadLine();
            Console.WriteLine("Name:"+name1);

            //Parsing
            int num1;
            Console.WriteLine("Enter Number 1:");
            num1 =int.Parse(Console.ReadLine());
            Console.WriteLine("Num1:" + num1);

            //using Convert 
            int num2;
            Console.WriteLine("Enter Number 2:");
            string value=(Console.ReadLine());
            num2 = Convert.ToInt32(value);
            Console.WriteLine("Num2:" + num2);
            #endregion 


        }
    }
}
