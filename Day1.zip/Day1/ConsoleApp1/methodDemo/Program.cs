﻿namespace methodDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Maths m=new Maths();
            //m.Add(2, 3);
            int z=Maths.Add(4, 5);
            Console.WriteLine("Addition of Two Numbers is:"+z);
        }
    }

    class Maths
    {

        //non-static
        //public void Add(int x,int y)
        //{
        //    int result=x+y;
        //    Console.WriteLine("Addition of Two Numbers is:"+result);
        //}


        //static method
        //public static void Add(int x, int y) // static
        //{
        //    int result = x + y;
        //    Console.WriteLine("Addition of Two Numbers is:"+result);
        //}


        //static method with return
        public static int Add(int x, int y) 
        {
            int result = x + y;
            return result;
        }
}
}
