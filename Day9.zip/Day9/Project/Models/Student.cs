﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Student
    {
        public int StudentId { get; set; }

        [Required]
        [MaxLength(12)]
        public string PRN { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? Email { get; set; }
        
        [MaxLength(15)]
        public string? MobileNo { get; set; }

        public int CourseId { get; set; }
        public Course Course { get; set; }
        public int CourseGroupId { get; set; }
        public CourseGroup CourseGroup { get; set; }

        public ICollection<Mark> Marks { get; set; } = new List<Mark>();

        public string AppUserId { get; set; }
        public AppUser AppUser { get; set; }

    }
}
