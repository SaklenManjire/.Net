﻿namespace Project.Models
{
    public class Tasks
    {
        public int TasksId { get; set; }

        public int StaffId { get; set; }
        public Staff Staff { get; set; } = null;
        public int CourseId { get; set; }
        public Course Course { get; set; } = null;
        public int SubjectId { get; set; }
        public Subject Subject { get; set; } = null;
        public int StudentId { get; set; }
        public Student Student { get; set; } = null;

        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }

        public bool isActive(DateTime now)
        {
            return now >= ValidFrom && now <= ValidTo;
        }

    }
}
