﻿namespace Project.Models
{
    public static class Utility
    {

    }
}
