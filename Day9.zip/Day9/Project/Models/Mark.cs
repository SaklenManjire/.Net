﻿namespace Project.Models
{
    public class Mark
    {
        public int MarkId { get; set; }


        //public int CourseId { get; set; }
        public int SubjectId { get; set; }
        public Subject Subject { get; set; } = null;
        public int StudentId { get; set; }
        public Student Student { get; set; } = null;

        public int TheoryMarks { get; set; }
        public int LabMarks { get; set; } 
        public int InternalMarks { get; set; }
        public string PassingStatus {  get; set; }

     

    }
}
