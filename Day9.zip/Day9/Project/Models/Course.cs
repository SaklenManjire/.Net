﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Course
    {
        public int CourseId { get; set; }

        [Required]
        [MaxLength(100)]
        public string  CourseName { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; } = string.Empty;

        [MaxLength(50)]
        public int Duration  { get; set; }
        public decimal Fee { get; set; }
        public ICollection<Student> Students { get; set; } = new List<Student>();
        public ICollection<CourseGroup> CourseGroups { get; set; } = new List<CourseGroup>();
        public ICollection<Subject> Subjects { get; set; } = new List<Subject>();


    }
}
