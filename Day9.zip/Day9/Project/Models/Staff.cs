﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Staff
    {
        public int StaffId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string  Email { get; set; } = string.Empty;

        [MaxLength(15)]
        public string? Mobile { get; set; }
        public string AppUserId { get; set; }
        public AppUser AppUser { get; set; }
        public ICollection<Tasks>  Tasks { get; set; } = new List<Tasks>();

    }
}
